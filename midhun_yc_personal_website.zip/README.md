# Midhun — Personal Website

Open `index.html` in a web browser to view the site. Keep the `assets` folder beside the HTML files.

Pages: Home → Work → About → Contact.

Contact details are configured with Midhun’s provided email, LinkedIn and GitHub links.

For GitHub Pages, upload the contents of this folder to the root of your repository.
